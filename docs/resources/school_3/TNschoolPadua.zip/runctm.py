"""Do 2D Ising simulations with CTM and evaluate data"""

import ctm
import numpy as np
import matplotlib.pyplot as pl
import os


rerun = 1   # set to 1 to rerun simulations (otherwise load data)

# Parameters:
vbeta = np.array([0.36, 0.38, 0.4, 0.41, 0.42, 0.43, 0.435, 0.438, 0.44, 0.4405, 0.441, 0.442, 0.444, 0.445, 0.45, 0.46, 0.47, 0.48, 0.49, 0.5, 0.55, 0.6])
#vbeta = np.array([0.3, 0.35, 0.4, 0.41, 0.42, 0.43, 0.435, 0.438, 0.44])
vchi = np.array([2,4,8,12,16])
tol = 1e-9
maxsteps = 20000
seed = 1
verbose = 0
datadir = 'data' # directory to save data


# create directory for data
if (not os.path.isdir(datadir)):
    os.mkdir(datadir)  


def dosims(chi, vbeta):
    """Collect data for chi and betas and save to file"""
    print('Do simulations for chi:',chi)
    m = np.zeros(vbeta.size)
    merr = np.zeros(vbeta.size)
    for k, beta in enumerate(vbeta):        
        m[k], merr[k] = ctm.doctm(beta, chi, tol, maxsteps, seed, verbose)
    
    res =  np.vstack((vbeta,m,merr)).transpose()
    # Open in binary mode for Python3 compatibility
    fname = datadir +'/Isingres_m_chi%s.txt' % (chi)
    print('Save in: ',fname)
    np.savetxt(fname,res)
    


if rerun:
    # perform series of simulations
    for chi in vchi:
        dosims(chi, vbeta)



# NOW EVALUATE AND MAKE PLOTS
def getdata(chi):
    "get data from file"
    fname = datadir +'/Isingres_m_chi%s.txt' % (chi)
    res = np.loadtxt(fname)
    return res



betacrit = 0.5*np.log(1 + np.sqrt(2)) # 0.44068679350977147

styles = ['b--', 'k:', 'r-.', 'g-', 'm--','k-']


# m versus beta for different chi
pl.figure(figsize = (10,4))
pl.subplot(1,2,1)
for k, chi in enumerate(vchi):
    dat = getdata(chi)
    pl.plot(dat[:,0], dat[:,1], styles[k], label='chi=%i' % chi)
    
pl.plot([betacrit, betacrit], [0,1], 'k--')
pl.xlabel(r'$\beta$')
pl.ylabel(r'$m$')
pl.legend(loc="upper left")

pl.subplot(1,2,2)
for k, chi in enumerate(vchi):
    dat = getdata(chi)
    pl.semilogy(dat[:,0], dat[:,2], styles[k], label='chi=%i' % chi)
    
pl.ylim([1e-15,1])    
pl.plot([betacrit, betacrit], pl.ylim(), 'k--')
pl.xlabel(r'$\beta$')
pl.ylabel(r'$error$')
pl.legend(loc="lower left")

pl.show()

pl.savefig('plot_m_beta.pdf')
 