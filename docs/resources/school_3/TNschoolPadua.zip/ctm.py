import numpy as np 
from ncon import ncon
import scipy.linalg as scl
import scipy.sparse.linalg as scspl


def doctm(beta=0.5, chi=8, tol=1e-8, maxsteps=1000, seed=1, verbose=1) :

    print('\nDo CTM for beta=',beta,', chi=',chi,', tol=',tol,', maxsteps=',maxsteps,', seed=',seed)
    
    minsteps = 10 
    # get exact value to compare with:
    betacrit = 0.5*np.log(1 + np.sqrt(2))
    if beta > betacrit:
    	mex = (1. - np.sinh(2*beta)**(-4) )**(1./8)
    else:
    	mex = 0
    
    # local Hamiltonian
    Hb = np.array([[-1.,1.],[1.,-1.]])
    # Q matrix
    Q = np.exp(-beta*Hb)
    # square root of Q matrix
    sQ = scl.sqrtm(Q)
    # define delta function on vertex
    delta = np.zeros([2,2,2,2])
    delta[0,0,0,0]=1.
    delta[1,1,1,1]=1.
    # and now contract delta with sQ on all legs
    a = ncon([delta,sQ,sQ,sQ,sQ],([1,2,3,4],[1,-1],[2,-2],[3,-3],[4,-4]))
    # define spin operator on vertex
    s = np.zeros([2,2,2,2])
    s[0,0,0,0]=1.
    s[1,1,1,1]=-1.
    # construct the b tensor to measure the local magnetization
    b = ncon([s,sQ,sQ,sQ,sQ],([1,2,3,4],[1,-1],[2,-2],[3,-3],[4,-4]))

    # initialize symmetric random boundary
    chi0 = 2 # initial boundary dimension
    np.random.seed(seed)
    C = np.random.rand(chi0,chi0) 
    C = C + C.transpose()
    T = np.random.rand(chi0,chi0,2)
    T = T + T.transpose([1,0,2])
    
    # do main loop
    sold = np.zeros(0)
    diffs = 1.
    for i in range(maxsteps):
        snew, C, T = doctmstep(C, T, a, chi)
        
        # compute difference in corner spectrum
        if snew.size == sold.size:
            diffs = np.sum(np.abs(snew-sold))
                    
        if (diffs<tol) and (i>minsteps):
            break
       
        if verbose:
            # compute magnetization
            m = getobs(b,C,T)
            nrm = getobs(a,C,T)
            m = np.abs(m/nrm)
            merr = np.abs(m-mex)
            print('step:',i,', m:', m,', diffs:', diffs,', err:', merr)
    
        sold = snew
     
    if (i==maxsteps-1) and (diffs>=tol):
        print('Warning: not converged after', i, ' steps', ', diffs =',diffs);
    else:
        print('CTM converged after', i, 'steps');
    # get final values:
    m = np.abs(getobs(b,C,T)/getobs(a,C,T))
    merr = np.abs(m-mex)
    print('m = ',m,', err:', merr)
    
    return m, merr    
      
        
    
def normalize(T):
        # divide by the largest element
        return T/np.max(np.abs(T))
    
def doctmstep(C,T,a,chi):
    # do one CTM step and return the new corner spectrum
    
    # compute corner (e.g. upper left)
    nC = ncon([C,T,T,a],([1,2],[-1,1,3],[2,-3,4],[-2,3,4,-4]));
    
    # resulting size of matrix
    s0 = nC.shape[0]
    s1 = nC.shape[1]
    msize = s0*s1
    targetdim = min(chi,msize)

    # reshape into matrix
    nC = nC.reshape(msize,msize)
    # symmetrize (nC might be non-symmetric due to round-off errors)

    nC = nC + nC.transpose()
    # U, sv, V = scsl.svd(nC)
    # truncate: this is not needed if eigsh below is used
    # sv = sv[:targetdim]
    # U = U[:,:targetdim]

    sv, U = scspl.eigsh(nC, k=targetdim, which='LM')

    # reshape V back into 3 legged tensor
    U = U.reshape(s0,s1,sv.size)
    # normalize
    sv = normalize(sv)
    # reshape V again
    # new corner matrix = eigenvalues
    C = np.diag(sv)
    # new T tensor:
    T = ncon([U,T,a,U],([1, 2, -1],[1, 4, 3],[-3, 2, 3, 5],[4, 5, -2])); 
    # symmetrize
    T = T + T.transpose([1,0,2])
    # normalize
    T = normalize(T)
    return sv,C,T
  
def getobs(b,C,T):
    # evaluate a 3x3 network with tensor M in the middle
    m=ncon([C,T,T,b,C,T,C,T,C],([1,2],[5,1,3],[2,12,4],[7,3,4,10],[5,6],[6,8,7],[8,9],[9,11,10],[11,12]));
    return m


if __name__ == "__main__":
    # This is a test run
    doctm(beta=0.5, chi=8, tol=1e-8, maxsteps=100000, seed=1, verbose=1)

