This folder contains the lecture and exercise for the Aqtivate workshop offered at TU Berlin in February 2024. The content is in part based on the PyML course content.
