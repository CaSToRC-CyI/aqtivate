import torch

import torch.nn as nn

from torch.utils.data import DataLoader, TensorDataset

from matplotlib import pyplot as plt

import numpy as np



# Specifiy the LeNet5 architecture
class Lenet5(nn.Module):
    def __init__(self, input_channels=1, num_classes=10, latent_dim=32):
        super().__init__()
        self.var =  nn.Linear(1, 1)
        self.counter = 0

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        self.counter += 1
        return x
        


def train_one_epoch(
        model: torch.nn.Sequential,
        train_loader: DataLoader,
        criterion: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
    ) -> [float, float]:

    # put the model into the training mode
    model.train()

    if not ( isinstance(model, torch.nn.Sequential) or
            isinstance(train_loader, DataLoader) or
            isinstance(criterion, torch.nn.Module) or
            isinstance(optimizer, torch.optim.Optimizer)) :
        return 0., 0.
    model(None)

    return len(train_loader), model.counter

@torch.no_grad()
def accuracy(model: torch.nn.Sequential, data_loader: DataLoader) -> float:

    if not (isinstance(model, torch.nn.Sequential) or isinstance(data_loader, DataLoader)):
        return 0.
        
    return len(data_loader)