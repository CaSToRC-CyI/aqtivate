function A = gauge_laplace(N)

i = sqrt(-1);

thetas = exp(-2*pi*i*rand(N*N,1));
phis = exp(-2*pi*i*rand(N*N,1));
e = ones(N*N,1);
A = spdiags([2*e,thetas,phis],[0,1,N+1],N*N,N*N);
A = A + A';
