% This is Jacobi and Gauss-Seidel for the discrete Laplacian 
% approximates Delta u = -4 on unit square, boundary = 0
fprintf('GAUGE LAPLACIAN\n');
N = input('N: no of inner grid points in one dimension: ');
A = gauge_laplace(N); 
n = size(A,1);
h = 1/(N+1);
b = h*h*ones(n,1);
u = rand(n,1);
u0 = u;
maxit = 10000; 
eps = input('eps: we stop when norm(residual) is reduced by factor eps: ');
% Jacobi
iter = 0;
resvec = zeros(maxit,1);
r = b-A*u;
norm0 = norm(r);
while ( (iter < maxit) && (norm(r) > eps*norm0))
    iter = iter+1;
    u = u+0.25*r;
    r = b-A*u;
    resvec(iter) = norm(r);
end


% Gauss-Seidel
iter2 = 0;
u = u0;
resvec2 = zeros(maxit,1);
r = b-A*u;
norm0 = norm(r);
L = tril(A);
while ( (iter2 < maxit) && (norm(r) > eps*norm0))
    iter2 = iter2+1;
    u = u+L\r;
    r = b-A*u;
    resvec2(iter2) = norm(r);
end
figure
semilogy((1:iter),resvec(1:iter),'-r',(1:iter2),resvec2(1:iter2),'-b');
legend('Jacobi','Gauss-Seidel');

%plot solution
figure
X = reshape(real(u),N,N);
mesh(X)

