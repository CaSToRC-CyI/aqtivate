% This is Jacobi or Gauss-Seidel for the discrete Laplacian 
% We plot the error as the iterations proceed
% approximates Delta u = -4 on unit square, boundary = 0
fprintf('GAUGE LAPLACIAN: Evolution of the error\n');
fprintf('The initial guess is a vector with random components\n');
N = input('N: no of inner grid points in one dimension: ');
type = input('0 for Jacobi, 1 for Gauss-Seidel: ');
A = gauge_laplace(N); 
n = size(A,1);
h = 1/(N+1);
b = h*h*ones(n,1);
sol = A\b;
u = rand(n,1);
u0 = u;
maxit = 25; 
iter = 0;
resvec = zeros(maxit,1);
r = b-A*u;
norm0 = norm(r);
if (type == 0) % Jacobi
    D = 4*speye(n);
else % Gauss-Seidel
    D = tril(A);
end
while ( (iter < maxit) )
    error = u-sol;
    fprintf('hit any key for error of iterate no %d/25\n',iter);
    pause
    mesh(abs(reshape(error,N,N)));
    iter = iter+1;
    u = u+D\r;
    r = b-A*u;
    resvec(iter) = norm(r);
end


