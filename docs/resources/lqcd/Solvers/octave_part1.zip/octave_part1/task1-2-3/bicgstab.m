function [x,iter,relres,resvec] = bicgstab(A,b,tol,maxit,x0)

m = length(b);

if(nargin < 3)
  tol = 10^(-10);
end

if(nargin < 4)
  maxit = 1000;
end

if(nargin < 5 || isempty(x0))
  x = zeros(m,1);
else
  x = x0;
end

%rstar = randn(m,1);
%rstar = rstar/norm(rstar);
resvec = zeros(2*maxit+1,1);

r = b - A*x;
normr = norm(r);
resvec(1) = normr;
rt = r;
rho = 1;
omega = 1;
alpha = [];

iter = 1;
while(normr/resvec(1) > tol && iter < maxit)
  rho1 = rho;
  rho = rt'*r;
  if(iter == 1)
    p = r;
  else
    beta = (rho/rho1)*(alpha/omega);
    p = r + beta*(p-omega*v);
  end
  v = A*p;
  rtv = rt'*v;
  alpha = rho/rtv;
  xhalf = x + alpha*p;
  s = r-alpha*v;
  normr = norm(s);
  resvec(2*iter) = normr;
  
  t = A*s;
  tt = t'*t;
  omega = (t'*s)/tt;
  
  x = xhalf + omega*s;
  r = s - omega*t;
  normr = norm(r);
  resvec(2*iter+1) = normr;
  iter = iter+1;
end

resvec = resvec(1:2*iter-1);
relres = normr/resvec(1);
