% Part I Task 2
% GMRES run-time
fprintf(stdout,'*** Task II: GMRES ***\n\n');

% Load matrix
filename = '4x4x4x4b6.0000id3n1.mat';
A = load(filename);
A = A.D;
m = size(A,1);

% Load spectrum
filename = '4x4x4x4b6.0000id3n1EW.mat';
ww = load(filename);
ww = ww.ww;
s = min(real(ww));
kappa = 10^(-8);
A = A - (s - kappa)*speye(m);

fprintf(stdout,'Running 4x4x4x4 Wilson Dirac Test\n');

%%%
fprintf (stdout,'\nPush a button to start part I\n');
fprintf (stdout,'convergence of GMRES\n\n');
pause
%%%

b = zeros(m,1);
b(1) = 1;
xstar = A\b;

evec = [norm(xstar)];
resvecI = [1];

itervec = (5:5:175);
for ii = 1:length(itervec)
  iter = itervec(ii);
  [x,relres,iterations,resvec,H] = gmres(A,b,iter,10^(-10),1);
  evec = [evec;norm(xstar-x)];
  resvecI = [resvecI;relres];
end

figure(1)
semilogy([0,itervec],resvecI,[0,itervec],evec);
xlabel('iterations')
legend('||r||_{2}','||e||_{2}')
title('GMRES 4x4x4x4 Wilson-Dirac')
box off;
grid on;

#{
%%%
fprintf (stdout,'\nPush a button to continue to part II\n');
fprintf (stdout,'run-time dependence on iteration number\n\n');
pause
%%%

b = zeros(m,1);
b(1) = 1;

tvec = [];
potvec = (3:8);
for ii = 1:length(potvec)
  iter = 2^potvec(ii);
  tic();
  [x,relres,iter,resvec,H] = gmres(A,b,iter,10^(-10),1);
  telapsed = toc();
  tvec = [tvec;telapsed];
end
  
figure(2)
loglog([8,16,32,64,128,256],tvec,'k',[8,16,32,64,128,256],[8,16,32,64,128,256].^2/(8^2/tvec(1)),'b',[8,16,32,64,128,256],[8,16,32,64,128,256].^3/(8^3/tvec(1)),'r');
legend('GMRES','O(k^2)','O(k^3)')
box off
grid on
xlabel('iterations k')
#}

%%%
fprintf (stdout,'\nPush a button to continue to part II\n');
fprintf (stdout,'the GMRES polynomial\n\n');
pause
%%%

B = A+(s-kappa)*speye(m);

[x,relres,iter,resvec,H] = gmres(A,b,100,10^(-10),1);

[X,Y] = meshgrid([linspace(0,8,64),linspace(-4,4,64)]);

z = X + sqrt(-1)*Y;
for i = 1:20
  l = eig(H(1:i,1:i));
  p = 1;
  for j = i:-1:1
    p = p.*(z-l(j))/(-l(j));
  end
  figure(3)
  plot(real(ww-s+kappa),imag(ww-s+kappa),'bx','Markersize',2,real(l),imag(l),'r*','Markersize',2);
  legend('eigenvalues of A','roots of p_{k}')
  title(cat(2,'the roots of the GMRES polynomial p_{',num2str(i),'}'))
  grid on
  box off
  axis([0 8 -4 4]);
  figure(4)
  contour(X,Y,abs(p),0:.1:1);axis([0 8 -4 4]);
  box off
  grid on
  title(cat(2,'contour of |p_{',num2str(i),'}|'))
  pause(1)
end


%%%
fprintf (stdout,'\nPush a button to continue to part IV\n');
fprintf (stdout,'GMRES vs GMRES(m)\n\n');
pause
%%%

resvecIV = cell(5,1);

restartvec = ([5,10,25,50,100]);
for ii = 1:length(resvecIV)
  restart = restartvec(ii);
  [x,relres,iter,resvec,H] = gmres(A,b,restart,10^(-10),(ceil(500/restart)));
  resvecIV{ii} = [resvec];
end

figure(5)
semilogy(0:restartvec(1):(length(resvecIV{1})-1)*restartvec(1),resvecIV{1},'-x','MarkerSize',2,...
         0:restartvec(2):(length(resvecIV{2})-1)*restartvec(2),resvecIV{2},'-x','MarkerSize',2,...
         0:restartvec(3):(length(resvecIV{3})-1)*restartvec(3),resvecIV{3},'-x','MarkerSize',2,...
         0:restartvec(4):(length(resvecIV{4})-1)*restartvec(4),resvecIV{4},'-x','MarkerSize',2,...         
         0:restartvec(5):(length(resvecIV{5})-1)*restartvec(5),resvecIV{5},'-x','MarkerSize',2,...         
         [0,itervec],resvecI,'-x','MarkerSize',2);
axis([0 500 10^(-10) 100]);
xlabel('iterations')
legend('GMRES(5)','GMRES(10)','GMRES(25)','GMRES(50)', 'GMRES(100)','GMRES',"location",'eastoutside')
title('GMRES vs. GMRES(m) 4x4x4x4 Wilson-Dirac')
box off;
grid on;

#{
%%%
fprintf (stdout,'\nPush a button to continue to part IV\n');
fprintf (stdout,'stagnation of GMRES(m)\n\n');
pause
%%%

fprintf('constructing pathological example of size 128x128')
N = 128;
e = ones(N,1);
G = spdiags([e e],[-1 N-1],N,N);

f = zeros(N,1);
f(1) = 1;

resvecV = cell(5,1);

restartvecV = ([8,16,32,64,128]);
for ii = 1:length(resvecV)
  restart = restartvecV(ii);
  [x,relres,iter,resvec,H] = gmres(G,f,restart,10^(-10),(ceil(256/restart)));
  resvecV{ii} = [resvec];
end

figure(6)
semilogy(0:restartvecV(1):(length(resvecV{1})-1)*restartvecV(1),resvecV{1},'-x','MarkerSize',2,...
         0:restartvecV(2):(length(resvecV{2})-1)*restartvecV(2),resvecV{2},'-x','MarkerSize',2,...
         0:restartvecV(3):(length(resvecV{3})-1)*restartvecV(3),resvecV{3},'-x','MarkerSize',2,...
         0:restartvecV(4):(length(resvecV{4})-1)*restartvecV(4),resvecV{4},'-x','MarkerSize',2,...         
         0:restartvecV(5):(length(resvecV{5})-1)*restartvecV(5),resvecV{5},'-x','MarkerSize',2,...
         [128 128],[0 200],'--k');      
axis([0 250 10^(-10) 100]);
xlabel('iterations')
legend('GMRES(8)','GMRES(16)','GMRES(32)','GMRES(64)', 'GMRES',"location",'eastoutside')
title('stagnation of GMRES(m)')
box off;
grid on;

figure(7)
spy(G,2,'*')
#}

%%%
fprintf (stdout,'\nPush a button to end task II\n');
pause
clear all
close all
%%%