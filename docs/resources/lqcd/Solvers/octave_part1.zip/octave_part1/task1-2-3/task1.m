% Part I of Task I 
% Testing CG on Poisson equation
% Measuring convergence in different norms
fprintf(stdout,'*** Task I: Conjugate Gradients ***\n\n');

N = 64;
fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
A = laplace(N);
m = size(A,1);
xstar = ones(m,1);
b = A*xstar;
beta = norm(b);
b = b/beta;
xstar = xstar/beta;

[x, flag, relres, iter, resvec, eigest, T, xvec] = pcg_local(A,b,10^(-10),500);

enormAvec = zeros(iter+1,1);
enormvec = zeros(iter+1,1);

for i = 1:iter+1
  e = xstar-xvec(:,i);
  enormAvec(i) = sqrt(e'*A*e);
  enormvec(i) = sqrt(e'*e);
end

fprintf(stdout,'CG converged in %3d iterations to ||r||_2 = %e\n',iter,relres);
fprintf(stdout,'                                  ||e||_2 = %e\n',enormvec(end));
fprintf(stdout,'                                  ||e||_A = %e\n',enormAvec(end));

figure(1)
semilogy(0:iter,resvec(1:iter+1),'r',0:iter,enormvec(1:iter+1),'b', 0:iter,enormAvec(1:iter+1),'k');
box off;
grid on;
xlabel('iterations');
title(cat(2,'Poisson on a ',num2str(N),'x',num2str(N),' grid'));
legend('||r||_{2}','||e||_{2}','||e||_{A}')

%%%
fprintf (stdout,'\nPush a button to continue... to part II\n\n');
pause
clear all
%%%

% Part II of Task I
% Eigenvalue localization of CG
% aka the CG polynomial

N = 16;
A = laplace(N);
m = size(A,1);
b = randn(m,1);
beta = norm(b);
b = b/beta;

[x, flag, relres, iter, resvec, eigest, T, xvec] = pcg_local(A,b,10^(-10),500);

ww = eig(A);

figure(2)
t = (0:.01:8)';
for i = 1:20
  l = eig(T(1:i,1:i));
  p = 1;
  for j = i:-1:1
    p = p.*(t-l(j))/(-l(j));
  end
  plot(real(ww),imag(ww),'bx','Markersize',2,real(l),imag(l),'r*', 'Markersize',2,t,p,'r');
  title(cat(2,'the CG polynomial p_{',num2str(i),'}'))
  legend('eigenvalues of A','roots of p_{k}','p_{k}')
  grid on
  box off

  axis([0 8 -1 1]);
  pause(1)
end

%%%
fprintf (stdout,'\nPush a button to continue... to part III\n\n');
pause
clear all
%%%

% Part III of Task I
% Dependence of convergence on kappa

kappa = zeros(5,1);
resvec = cell(5,1);
for i = 1:5
  resvec{i} = [];
end

xstar = cell(5,1);

for jj = 3:7
  N = 2**jj;
  fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
  A = laplace(N);
  m = size(A,1);
  b = zeros(m,1);
  b((N+1)*N/2) = 1;
  beta = norm(b);
  b = b/beta;
  
  [xstar{jj-2}, flag, relres, iter, resvec{jj-2}, eigest, T] = pcg_local(A,b,10^(-10),500);
  fprintf(stdout,'CG converged in %3d iterations to ||r||_2 = %e\n',iter,relres);
  l = eig(T);
  kappa(jj-2) = max(l)/min(l);
end

figure(3)
semilogy(1:length(resvec{1}),resvec{1}(:,1),'b',...
         1:length(resvec{2}),resvec{2}(:,1),'g',...
         1:length(resvec{3}),resvec{3}(:,1),'r',...
         1:length(resvec{4}),resvec{4}(:,1),'c',...
         1:length(resvec{5}),resvec{5}(:,1),'k');
legend('8x8','16x16','32x32','64x64','128x128')
ylabel('||r||_{2}');
xlabel('iterations');
title('dependence of iterations on N')
grid on
box off
axis([0 ceil(length(resvec{5})/100)*100 10^(-10) 100])

figure(4)
loglog([8,16,32,64,128],kappa);
ylabel('\kappa');
xlabel('N');
title('dependence of \kappa on N')
grid on
box off

figure(6)
mesh(linspace(1/(2^(2+2)+2),1-1/(2^(2+2)+2),2^(2+2)),linspace(1/(2^(2+2)+2),1-1/(2^(2+2)+2),2^(2+2)),reshape(xstar{2},2^(2+2),2^(2+2)))
title('solution on 16x16 grid')

figure(7)
mesh(linspace(1/(2^(2+4)+2),1-1/(2^(2+4)+2),2^(2+4)),linspace(1/(2^(2+4)+2),1-1/(2^(2+4)+2),2^(2+4)),reshape(xstar{4},2^(2+4),2^(2+4)))
title('solution on 64x64 grid')

%%%
fprintf (stdout,'\nPush a button to continue... to part IV\n');
fprintf (stdout,'dependence of convergence on b\n\n');
pause
clear all
%%%

% Part IV of Task I
% Dependence of convergence on right hand side

N = 16;
A = laplace(N);
m = size(A,1);

xstar = ones(m,1);
e1 = zeros(m,1);
e1(N*(N+1)/2) = 1;

[vv,ww] = eig(A);

B = [randn(m,1),vv(:,1),vv(:,1)+vv(:,2),e1,A*xstar];
nb = size(B,2);

for i=1:nb
  B(:,i) = B(:,i)/norm(B(:,i));
end

resvec = cell(nb,1);
for i=1:nb
  [x, flag, relres, iter, resvec{i}] = pcg_local(A,B(:,i), ...
                                                    10^(-10),500);
  fprintf(stdout,['CG converged in %3d iterations to ||r||_2 = ' ...
  '%e\n'],iter,relres);
end  
figure(5)
semilogy(1:length(resvec{1}),resvec{1}(:,1),'b',...
         1:length(resvec{2}),resvec{2}(:,1),'g',...
         1:length(resvec{3}),resvec{3}(:,1),'r',...
         1:length(resvec{4}),resvec{4}(:,1),'c',...
         1:length(resvec{5}),resvec{5}(:,1),'k');
%legend('random','v_{1}','v_{1}+v_{2}','point-source','A*const')
ylabel('||r||_{2}');
xlabel('iterations');
title('dependence of iterations on b')
grid on
box off
axis([0 ceil(length(resvec{1})/100)*100 10^(-10) 100])

%%%
fprintf (stdout,'\nPush a button to finish Task I\n\n');
pause
clear all
close all
%%%
