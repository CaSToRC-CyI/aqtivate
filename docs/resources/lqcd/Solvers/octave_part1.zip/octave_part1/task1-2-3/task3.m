% Task III, Part I
% BiCGstab

fprintf(stdout,'*** Task III: BiCGstab ***\n\n');

% Load matrix
filename = '4x4x4x4b6.0000id3n1.mat';
A = load(filename);
A = A.D;
m = size(A,1);

% Load spectrum
filename = '4x4x4x4b6.0000id3n1EW.mat';
ww = load(filename);
ww = ww.ww;
s = min(real(ww));
kappa = 10^(-8);
A = A - (s - kappa)*speye(m);

fprintf(stdout,'Running 4x4x4x4 Wilson Dirac Test\n');

%%%
fprintf (stdout,'\nPush a button to start part I\n');
fprintf (stdout,'convergence of BiCGstab\n\n');
pause
%%%

b = zeros(m,1);
b(1) = 1;
xstar = A\b;
[x, iterBiCG, relres, resvecBiCG] = bicgstab(A, b, 10^(-10), 200);

figure(1)
semilogy(0:2*(iterBiCG-1),resvecBiCG);
box off
grid on
xlabel('MatVecs')
ylabel('||r||_{2}')
title('BiCGstab 4x4x4x4 Wilson-Dirac')

%%%
fprintf (stdout,'\nPush a button to continue with part II\n');
fprintf (stdout,'comparison CGN, GMRES, BiCGstab\n\n');
pause
%%%

% Task III, Part II
% Comparison of GMRES, BiCGstab, CGN

resvecGMRES = [1];
itervec = (5:5:175);
for ii = 1:length(itervec)
  iter = itervec(ii);
  [x,relres,iterations,resvec,H] = gmres(A,b,iter,10^(-10),1);
  resvecGMRES = [resvecGMRES;relres];
end
[x,relres,iterGMRES,resvecGMRESm,H] = gmres(A,b,32,10^(-10),8);

[x, flag, relres, iter, resvecCGN] = pcg_local(A'*A,A'*b,10^(-10),500);

figure(2)
semilogy(0:length(resvecBiCG)-1,resvecBiCG,...
         [0:5:175],resvecGMRES,...
         [0:32:256],resvecGMRESm,...
         0:2:2*(length(resvecCGN)-1),resvecCGN);
axis([0 250 10^(-10) 100]);
box off
grid on
xlabel('MatVecs')
ylabel('||r||_{2}')
title('4x4x4x4 Wilson-Dirac')
legend('BiCGstab','GMRES','GMRES(32)','CGN')

%%%
fprintf (stdout,'\nPush a button to finish Task III\n\n');
pause
clear all
close all
%%%

