import torch
import torch.nn
from torch import nn


def exercise1():
	class LSTMNetwork(nn.Module):
		def __init__(self):
			super().__init__()
			self.lstm1 = nn.LSTMCell(1, 25)
			self.lstm2 = nn.LSTMCell(25, 25)
			self.linear = nn.Linear(25, 1)
		
		def forward(self, input, prediction_steps=0):
			outputs = []
			h_t = torch.zeros(input.size(0), 25, dtype=torch.double)
			c_t = torch.zeros(input.size(0), 25, dtype=torch.double)
			h_t2 = torch.zeros(input.size(0), 25, dtype=torch.double)
			c_t2 = torch.zeros(input.size(0), 25, dtype=torch.double)
			
			for input_t in input.split(1, dim=1):
				h_t, c_t = self.lstm1(input_t, (h_t, c_t))
				h_t2, c_t2 = self.lstm2(h_t, (h_t2, c_t2))
				output = self.linear(h_t2)
				outputs += [output]
    
			for i in range(prediction_steps):  # if we should predict the future
				h_t, c_t = self.lstm1(output, (h_t, c_t))
				h_t2, c_t2 = self.lstm2(h_t, (h_t2, c_t2))
				output = self.linear(h_t2)
				outputs += [output]
			outputs = torch.cat(outputs, dim=1)
			return outputs
	
	lstm = LSTMNetwork()
	return lstm


def exercise2():
	
	optimizer.zero_grad()
	out = lstm(input)
	loss = criterion(out, target)
	loss.backward()
	optimizer.step()
	
