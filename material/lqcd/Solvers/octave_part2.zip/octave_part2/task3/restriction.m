function [ uc ] = restriction( u )
% given (n)x(n) array u where u[i,j] corresponds to grid point 
% at position (i)*h, (j)*h where hc = 1/(n+1)
% restrcits to uc, an (nc)x(nc) array with n = 2nc+1,
% grid points (i)h,(j)h with h = 1/(nc+1)
% uses the 9-point stencil
n= size(u,1);
if (mod(n,2) == 0)
    fprintf('error: grid size not odd on fine grid')
    return
else
    nc = floor(n/2);
    uc = zeros(nc);
    uc = 0.25*u(2:2:n-1,2:2:n-1) + ...
         0.125*u(1:2:n-2,2:2:n-1) + 0.125*u(3:2:n,2:2:n-1) + ...
         0.125*u(2:2:n-1,1:2:n-2) + 0.125*u(2:2:n-1,3:2:n) + ...
         .0625*u(1:2:n-2,1:2:n-2) + .0625*u(1:2:n-2,3:2:n) + ...
         .0625*u(3:2:n,1:2:n-2)   + .0625*u(3:2:n,3:2:n) ;      
end
