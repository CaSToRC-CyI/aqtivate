function [ u, r ] = smoothing( u,b,nu )
% u and b are given as nxn arrays
% on output, u is the result of the smoothing
% r is the residual b - A*u
% Is this Gauss-Seidel or Jacobi smoothing?
% Or a variant with a relaxation parameter?
% You should find out
r = b-Laplace_mult(u);
omega = 0.8;
for j = 1:nu
    u = u + 0.8*0.25*r;
    r = b-Laplace_mult(u);
    end
end

