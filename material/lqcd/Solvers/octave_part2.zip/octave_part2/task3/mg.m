function [e] = mg( r, nu )
%performs the multi-grid recursion
% nu is the number of pre-smoothing steps
% r given as N x N array
n = size(r,1);
if (n < 6) % solve by a direct method
    A = laplace(n);
    e = reshape(A\reshape(r,n*n,1),n,n);
else
    [e,r] = smoothing(zeros(n),r,nu);
    rc = restriction(r);
    ec = mg(rc,nu);
    e = e + prolongation(ec);
end
end
