function [ u ] = prolongation( uc )
% given (nc)x(nc) array u where u[i,j] corresponds to grid point 
% at position (i)*hc, (j)*hc where hc = 1/(nc+1)
% interpolates to u, an (n)x(n) array with n = 2nc+1,
% grid points (i)h,(j)h with h = 1/(n+1)
% uses the 9-point stencil
% multiplies by 4 at the end to account for the fact that 
%our Lpalcians are not scaled by h^2, h the discetization length
nc = size(uc,1);
n = 2*nc +1;
u = zeros(n);
u(2:2:n-1,2:2:n-1) = uc;
u(1:2:n-2,2:2:n-1) = 0.5*uc;
u(3:2:n,2:2:n-1) = u(3:2:n,2:2:n-1)+0.5*uc;
u(2:2:n-1,1:2:n-2) = 0.5*uc;
u(2:2:n-1,3:2:n) = u(2:2:n-1,3:2:n)+0.5*uc;
u(1:2:n-2,1:2:n-2) = 0.25*uc;
u(3:2:n,1:2:n-2) = u(3:2:n,1:2:n-2)+0.25*uc;
u(1:2:n-2,3:2:n) = u(1:2:n-2,3:2:n)+0.25*uc;
u(3:2:n,3:2:n) = u(3:2:n,3:2:n)+0.25*uc;
u = 4*u;

end


