function [ y ] = Laplace_mult( x )
% y = discrete Laplacian times x, where both, x and y are n x n arrays
%   
n = size(x,1);
X = zeros(n+2,n+2);
X(2:n+1,2:n+1) = x;
y = 4*X(2:n+1,2:n+1)-X(1:n,2:n+1)-X(2:n+1,1:n)-X(3:n+2,2:n+1)-X(2:n+1,3:n+2);
end

