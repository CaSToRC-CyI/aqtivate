function [sol iter] = multi_grid( b, nu )
%performs a mult-grid method for Ax = b
% A discrete Laplacian on N x N grid, N = 2^^p-1
% nu is the number of pre-smoothing steps
% b given as N x N array
% the recursive calls are in mg.m
eps = 1e-10;
n = size(b,1);
nc = floor(n/2);
Ac = laplace(nc);
u = rand(n);
r = b-Laplace_mult(u);
iter = 0;
while (norm(r,'fro') > eps)  
      [e,r] = smoothing(zeros(n),r,nu);
      u = u+e;
      rc = restriction(r);
      solc = mg(rc,nu);
      u = u + prolongation(solc);
      r = b - Laplace_mult(u);
      iter = iter+1;
end
sol = u;
iter

end

