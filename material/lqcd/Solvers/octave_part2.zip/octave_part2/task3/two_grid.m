function [sol iter] = two_grid( b, nu )
%perfomrs a two-grid method for Ax = b
% A discrete Laplacian on N x N grid, N odd
% nu is the number of pre-smoothing steps
% b given as N x N array
eps = 1e-10;
n = size(b,1);
nc = floor(n/2);
Ac = laplace(nc);
u = rand(n);
r = b-Laplace_mult(u);
iter = 0;
while (norm(r,'fro') > eps)  
      [e,r] = smoothing(zeros(n),r,nu);
      u = u+e;
      rc = restriction(r);
      solc = reshape(Ac\reshape(rc,nc*nc,1),nc,nc);
      u = u + prolongation(solc);
      r = b - Laplace_mult(u);
      iter = iter+1;
end
sol = u;
iter

end

