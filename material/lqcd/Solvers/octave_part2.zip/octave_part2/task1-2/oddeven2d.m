function x = oddeven2d(b,varargin)

A = varargin{1};
tol = varargin{2};

m = length(b);

N = sqrt(m);

x = zeros(m,1);

odd = [];
even = [];
for i = 1:N
  for j = 1:N
    if(mod(i+j,2))
      odd = [odd;(i-1)*N+j];
    else
      even = [even;(i-1)*N+j];
    end
  end
end

S = A(even,even) - A(even,odd)*(A(odd,odd)\A(odd,even));
y = zeros(length(odd));

y = A(odd,odd)\b(odd);
[x(even),flag,iter,relres,resvec] = pcg(S,b(even)-A(even,odd)*y,tol,100);
%x(even) = S\(b(even)-A(even,odd)*y);
x(odd) = y - A(odd,odd)\(A(odd,even)*x(even));