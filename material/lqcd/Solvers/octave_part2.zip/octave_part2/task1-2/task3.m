% Part I of Task II 
% Testing preconditioned BiCG
fprintf(stdout,'*** Task II: pGMRES ***\n\n');

% Load matrix
filename = '4x4x4x4b6.0000id3n1.mat';
A = load(filename);
A = A.D;
m = size(A,1);
geometry = [4;4;4;4];

% Load spectrum
filename = '4x4x4x4b6.0000id3n1EW.mat';
ww = load(filename);
ww = ww.ww;
s = min(real(ww));
kappa = 10^(-8);
A = A - (s - kappa)*speye(m);

fprintf(stdout,'Running 4x4x4x4 Wilson Dirac Test\n');

%%% Task I 
% Standard BiCGstab

%%%
fprintf (stdout,'\nPush a button to start\n');
fprintf (stdout,'stand-alone BiCGstab\n');
pause
%%%

b = zeros(m,1);
b(1) = 1;
xstar = A\b;

% Standard BiCG
[x, iterBiCG, relres, resvecBiCG] = pbicgstab(A,b,10^(-10),200);

figure(1)
semilogy(0:2*(iterBiCG-1),resvecBiCG);
xlabel('iterations')
ylabel('||r||_{2}');
legend('BiCGstab');
title('preconditioned BiCGstab 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;
%
%%% Task II Part I
% DD BiCG

%%%
fprintf (stdout,'\nPush a button to continue with part I\n');
fprintf (stdout,'domain-decomposition BiCGstab\n');
pause
%%%

[x, iterDD, relres, resvecDD] = pbicgstab(A,b,10^(-10),200,[],"bcgs",[],A,geometry,[2,2,2,2]);

figure(2)
semilogy(0:2*(iterBiCG-1),resvecBiCG,...
         0:2*(iterDD-1),resvecDD);
xlabel('iterations')
ylabel('||r||_{2}');
legend('BiCGstab','DD(2^{4})-BiCGstab')
title('preconditioned BiCGstab 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;

%%% Task II Part II
% ILU BiCG

%%%
fprintf (stdout,'\nPush a button to continue with part II\n');
fprintf (stdout,'ILU BiCGstab\n');
pause
%%%

[L,U,P,Q] = luinc(A,10^(-3));
P = sparse(1:m,P,ones(m,1),m,m);
Q = sparse(1:m,Q,ones(m,1),m,m);
L = P'*L;
U = U*Q';

fprintf(stdout,'nnz(A)/nnz(L+U) = %f\n\n',nnz(A)/nnz(L+U));

[x, iterILU, relres, resvecILU]  = pbicgstab(A,b,10^(-9),200,[],U,L);

figure(3)
semilogy(0:2*(iterBiCG-1),resvecBiCG,...
         0:2*(iterDD-1),resvecDD,...
         0:2*(iterILU-1),resvecILU);
xlabel('iterations')
ylabel('||r||_{2}');
legend('BiCGstab','DD(2^{4})-BiCGstab','ILU(10^{-1})-BiCGstab')
title('preconditioned BiCG 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;
%}

%%% Task II Part III
% odd-even Preconditioning
%%%
fprintf (stdout,'\nPush a button to continue with part III\n');
fprintf (stdout,'odd-even Preconditioning\n');
pause
%%%

[x, iterOE, relres, resvecOE] = pbicgstab(A,b,10^(-10),200,[],"oddeven4d",[],A,10^(-1),geometry);

figure(4)
semilogy(0:2*(iterBiCG-1),resvecBiCG,...
         0:2*(iterDD-1),resvecDD,...
         0:2*(iterILU-1),resvecILU,...
         0:2*(iterOE-1),resvecOE);
xlabel('iterations')
ylabel('||r||_{2}');
legend('BiCGstab','DD(2^{4})-BiCGstab','ILU(10^{-1})-BiCGstab','OE(10^{-1})-BiCGstab')
title('preconditioned BiCGstab 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;

%%%
fprintf (stdout,'\nPush a button to finish Task III\n\n');
pause
clear all
close all
%%%
