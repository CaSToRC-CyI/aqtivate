function [block,color] = blockand2color4DQCD(gridgeometry,blockgeometry)

mm = 3;
for i = 1:length(gridgeometry)
   mm = mm*gridgeometry(i);
end

[bb,color] = blockandcolor(gridgeometry,blockgeometry);

[nb,nnb] = size(bb);

block = zeros(nb,12*nnb);
for i = 1:nb
   bh = bb(i,:);
   bh = [(3*bh-2) (3*bh-1) (3*bh)];
   bh = sort(bh);
   bh = [(bh) (mm+bh) (2*mm+bh) (3*mm+bh)];
   block(i,:) = bh;
end
