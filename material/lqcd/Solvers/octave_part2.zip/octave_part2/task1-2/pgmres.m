function [x,relres,iter,resvec,H] = pgmres(A,b,restart,tol,maxit,M1,M2,x0,varargin)

n = length(b);

if(nargin < 3)
  restarted = 0;
else
  restarted = 1;
end

if(nargin < 4)
  tol = 10^(-10);
end

if (nargin < 5) || isempty(maxit)
  if restarted
    maxit = min(ceil(n/restart),10);
  else
    maxit = min(n,10);
  end
end

if (nargin < 6 || isempty (M1))
  exist_m1 = 0;
else
  exist_m1 = 1;
end

if (nargin < 7 || isempty (M2))
  exist_m2 = 0;
else
  exist_m2 = 1;
end


if restarted
  outer = maxit;
  if restart > n
    restart = n;
  end
  inner = restart;
else
  outer = 1;
  if maxit > n
    maxit = n;
  end
  inner = maxit;
end

if(nargin < 8 || isempty(x0))
  x = zeros(n,1);
else
  x = x0;
end

V = zeros(n,inner+1);
H = zeros(inner+1,inner);
e1 = zeros(inner+1,1);
e1(1) = 1;

resvec = zeros(outer*inner,1);
  
outiter = 0;
r = b - A*x;
if(exist_m2)
  if(isnumeric(M2))
    r = M2 \ r;
  else
    r = feval(M2, r, varargin{:});
  end
end
if(exist_m1)
  if(isnumeric(M1))
    r = M1 \ r;
  else
    r = feval(M1, r, varargin{:});
  end
end
normr = norm(r);
normr0 = normr;
resvec(1) = normr;

while(normr/normr0 > tol && outiter < outer);
  V(:,1) = r/normr;
  for jj = 1:inner
    w = A*V(:,jj);
    if (exist_m2)
      if(isnumeric(M2))
        w = M2 \ w;
      else
        w = feval(M2, w, varargin{:});
      end
    end
    if (exist_m1)
      if(isnumeric(M1))
        w = M1 \ w;
      else
        w = feval(M1, w, varargin{:});
      end
    end
    for ii = 1:jj
      H(ii,jj) = V(:,ii)'*w;
      w = w - H(ii,jj)*V(:,ii);
    end
    H(jj+1,jj) = norm(w);
    V(:,jj+1) = w/H(jj+1,jj);
  end
  y = H\(normr*e1);
  x = x + V(:,1:inner)*y;
  r = b - A*x;
  normr = norm(r);
  
  outiter = outiter+1;
  resvec(outiter+1) = normr;
end
iter = [outiter*inner];
resvec = resvec(1:outiter+1);
relres = normr/normr0;