function [block,color] = blockandcolor(gridgeometry,blockgeometry)

for i = 1:4
   if((mod(gridgeometry(i),2*blockgeometry(i))~=0) && ~(gridgeometry(i)/blockgeometry(i)==1))
      error('Incompatible blockgeometry!');
   end
end

nbd = [(gridgeometry(1)/blockgeometry(1));(gridgeometry(2)/blockgeometry(2));(gridgeometry(3)/blockgeometry(3));(gridgeometry(4)/blockgeometry(4))];
nb = nbd(1)*nbd(2)*nbd(3)*nbd(4);
bsize = blockgeometry(1)*blockgeometry(2)*blockgeometry(3)*blockgeometry(4);

block = zeros(nb,bsize);
color = zeros(nb,1);

for i4 = 1:nbd(4)
   for i3 = 1:nbd(3)
      for i2 = 1:nbd(2)
         for i1 = 1:nbd(1)
            color(i1+((i2-1)+((i3-1)+(i4-1)*nbd(3))*nbd(2))*nbd(1)) = mod(i1+i2+i3+i4,2);
         end
      end
   end
end

for i4 = 1:blockgeometry(4)
   for i3 = 1:blockgeometry(3)
      for i2 = 1:blockgeometry(2)
         bind = ((((i4-1))*blockgeometry(3)+(i3-1))*blockgeometry(2)+(i2-1))*blockgeometry(1)+(1:blockgeometry(1));
         bpart = ((((i4-1))*gridgeometry(3)+(i3-1))*gridgeometry(2)+(i2-1))*gridgeometry(1)+(1:blockgeometry(1));
         block(1,bind) = bpart;
      end
   end
end

bshift = 0;
for i4 = 1:nbd(4)
   for i3 = 1:nbd(3)
      for i2 = 1:nbd(2)
         for i1 = 1:nbd(1)
            bshift = (i4-1)*gridgeometry(3)*gridgeometry(2)*gridgeometry(1)*blockgeometry(4)+(i3-1)*gridgeometry(2)*gridgeometry(1)*blockgeometry(3)+(i2-1)*gridgeometry(1)*blockgeometry(2)+(i1-1)*blockgeometry(1);
            block(i1+((i2-1)+((i3-1)+(i4-1)*nbd(3))*nbd(2))*nbd(1),:) = block(1,:)+bshift;
         end
      end
   end
end