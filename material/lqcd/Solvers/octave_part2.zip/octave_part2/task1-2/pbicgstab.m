function [x,iter,relres,resvec] = pbicgstab(A,b,tol,maxit,x0,M1,M2,varargin)

m = length(b);

if(nargin < 3)
  tol = 10^(-10);
end

if(nargin < 4)
  maxit = 1000;
end

if(nargin < 5 || isempty(x0))
  x = zeros(m,1);
else
  x = x0;
end

if(nargin < 6 || isempty(M1))
  exist_m1 = 0;
else
  exist_m1 = 1;
end

if(nargin < 7 || isempty(M2))
  exist_m2 = 0;
else
  exist_m2 = 1;
end

resvec = zeros(2*maxit+1,1);

r = b - A*x;
normr = norm(r);
resvec(1) = normr;
rt = r;
rho = 1;
omega = 1;
alpha = [];

iter = 1;
while(normr/resvec(1) > tol && iter < maxit)
  rho1 = rho;
  rho = rt'*r;
  if(iter == 1)
    p = r;
  else
    beta = (rho/rho1)*(alpha/omega);
    p = r + beta*(p-omega*v);
  end
  ph = p;
  if(exist_m2)
    if(isnumeric(M2))
      ph = M2 \ ph;
    else
      ph = feval(M2, ph, varargin{:});
    end
  end
  if(exist_m1)
    if(isnumeric(M1))
      ph = M1 \ ph;
    else
      ph = feval(M1, ph, varargin{:});
    end
  end
  v = A*ph;
  rtv = rt'*v;
  alpha = rho/rtv;
  xhalf = x + alpha*ph;
  
  s = r-alpha*v;
  normr = norm(s);
  resvec(2*iter) = normr;
  sh = s;
  if(exist_m2)
    if(isnumeric(M2))
      sh = M2 \ sh;
    else
      sh = feval(M2, sh, varargin{:});
    end
  end
  if(exist_m1)
    if(isnumeric(M1))
      sh = M1 \ sh;
    else
      sh = feval(M1, sh, varargin{:});
    end
  end
  t = A*sh;
  tt = t'*t;
  omega = (t'*s)/tt;
  
  x = xhalf + omega*sh;
  r = s - omega*t;
  normr = norm(r);
  resvec(2*iter+1) = normr;
  iter = iter+1;
end

resvec = resvec(1:2*iter-1);
relres = normr/resvec(1);
