% Part I of Task II 
% Testing preconditioned GMRES
fprintf(stdout,'*** Task II: pGMRES ***\n\n');

% Load matrix
filename = '4x4x4x4b6.0000id3n1.mat';
A = load(filename);
A = A.D;
m = size(A,1);
geometry = [4;4;4;4];

% Load spectrum
filename = '4x4x4x4b6.0000id3n1EW.mat';
ww = load(filename);
ww = ww.ww;
s = min(real(ww));
kappa = 10^(-8);
A = A - (s - kappa)*speye(m);

fprintf(stdout,'Running 4x4x4x4 Wilson Dirac Test\n');

%%% Task I 
% Standard GMRES

%%%
fprintf (stdout,'\nPush a button to start\n');
fprintf (stdout,'stand-alone GMRES\n');
pause
%%%

b = zeros(m,1);
b(1) = 1;
xstar = A\b;


resvecI = [1];
% Standard GMRES
itervec = (5:5:175);
for ii = 1:length(itervec)
  iter = itervec(ii);
  [x,relres,iterations,resvec,H] = pgmres(A,b,iter,10^(-10),1);
  resvecI = [resvecI;relres];
end

figure(1)
semilogy([0,itervec],resvecI);
xlabel('iterations')
ylabel('||r||_{2}');
legend('GMRES');
title('preconditioned GMRES 4x4x4x4 Wilson-Dirac')
box off;
grid on;


%%% Task II Part I
% DD GMRES

%%%
fprintf (stdout,'\nPush a button to continue with part I\n');
fprintf (stdout,'domain-decomposition GMRES\n');
pause
%%%

resvecDD = [1];
itervecDD = (5:5:60);
for ii = 1:length(itervecDD)
  iter = itervecDD(ii);
  [x,relres,iterations,resvec,H] = pgmres(A,b,iter,10^(-10),1,"bcgs",[],[],A,geometry,[2,2,2,2]);
  resvecDD = [resvecDD;relres];
end

figure(2)
semilogy([0,itervec(1:length(resvecI)-1)],resvecI,[0,itervecDD(1:length(resvecDD)-1)],resvecDD);
xlabel('iterations')
ylabel('||r||_{2}');
legend('GMRES','DD(2^{4})-GMRES')
title('preconditioned GMRES 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;

#{
%%% Task II Part II
% ILU GMRES

%%%
fprintf (stdout,'\nPush a button to continue with part II\n');
fprintf (stdout,'ILU GMRES\n');
pause
%%%

[L,U,P,Q] = luinc(A,10^(-1));
P = sparse(1:m,P,ones(m,1),m,m);
Q = sparse(1:m,Q,ones(m,1),m,m);
L = P'*L;
U = U*Q';

fprintf(stdout,'nnz(A)/nnz(L+U) = %f\n\n',nnz(A)/nnz(L+U));

resvecILU = [1];
itervecILU = (1:1:10);
for ii = 1:length(itervecILU)
  iter = itervecILU(ii);
  [x,relres,iterations,resvec,H] = pgmres(A,b,iter,10^(-9),1,L,U,[]);
  resvecILU = [resvecILU;relres];
end

figure(3)
semilogy([0,itervec(1:length(resvecI)-1)],resvecI,...
         [0,itervecDD(1:length(resvecDD)-1)],resvecDD,...
         [0,itervecILU(1:length(resvecILU)-1)],resvecILU);
xlabel('iterations')
ylabel('||r||_{2}');
legend('GMRES','DD(2^{4})-GMRES','ILU(10^{-1})-GMRES')
title('preconditioned GMRES 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;
#}

%%% Task II Part II
% odd-even Preconditioning
%%%
fprintf (stdout,'\nPush a button to continue with part II\n');
fprintf (stdout,'odd-even Preconditioning\n');
pause
%%%

resvecOE = [1];
% odd-even preconditioned gmres
itervecOE = (2:2:10);
for ii = 1:length(itervecOE)
  iter = itervecOE(ii);
  [x,relres,iterations,resvec,H] = pgmres(A,b,iter,10^(-10),1,"oddeven4d",[],[],A,10^(-3),geometry);
  resvecOE = [resvecOE;relres];
end

figure(4)
semilogy([0,itervec(1:length(resvecI)-1)],resvecI,...
         [0,itervecDD(1:length(resvecDD)-1)],resvecDD,...
         %[0,itervecILU(1:length(resvecILU)-1)],resvecILU,...
         [0,itervecOE(1:length(resvecOE)-1)],resvecOE);
xlabel('iterations')
ylabel('||r||_{2}');
legend('GMRES','DD(2^{4})-GMRES','OE(10^{-3})-GMRES')
title('preconditioned GMRES 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;

%%% Task II Part III
% odd-even Preconditioning flexible GMRES
%%%
fprintf (stdout,'\nPush a button to continue with part III\n');
fprintf (stdout,'odd-even Preconditioning FGMRES\n');
pause
%%%

resvecOEF = [1];
% odd-even preconditioned fgmres
itervecOEF = (2:2:10);
for ii = 1:length(itervecOEF)
  iter = itervecOEF(ii);
  [x,relres,iterations,resvec,H] = pfgmres(A,b,iter,10^(-10),1,"oddeven4d",[],[],A,10^(-3),geometry);
  resvecOEF = [resvecOEF;relres];
end

figure(4)
semilogy([0,itervec(1:length(resvecI)-1)],resvecI,...
         [0,itervecDD(1:length(resvecDD)-1)],resvecDD,...
         %[0,itervecILU(1:length(resvecILU)-1)],resvecILU,...
         [0,itervecOEF(1:length(resvecOEF)-1)],resvecOEF);
xlabel('iterations')
ylabel('||r||_{2}');
legend('GMRES','DD(2^{4})-GMRES','OE(10^{-3})-FGMRES')
title('preconditioned GMRES 4x4x4x4 Wilson-Dirac')
axis([0 200 10^(-10) 100])
box off;
grid on;

%%%
fprintf (stdout,'\nPush a button to finish Task II\n\n');
pause
clear all
close all
%%%
