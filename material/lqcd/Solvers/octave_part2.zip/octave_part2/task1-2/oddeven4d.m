function x = oddeven4d(b,varargin)

A = varargin{1};
tol = varargin{2};
geometry = varargin{3};

m = length(b);

x = zeros(m,1);

nc = 3;
V = prod(geometry);

odd = [];
even = [];
for i4 = 1:geometry(4)
  for i3 = 1:geometry(3)
    for i2 = 1:geometry(2)
      for i1 = 1:geometry(1)
        if(mod(i1+i2+i3+i4,2))
          odd = [odd;i1+geometry(1)*((i2-1)+geometry(2)*((i3-1)+geometry(3)*(i4-1)))];
        else
          even = [even;i1+geometry(1)*((i2-1)+geometry(2)*((i3-1)+geometry(3)*(i4-1)))];
        end
      end
    end
  end
end

odd = [3*odd;3*odd-1;3*odd-2];
even = [3*even;3*even-1;3*even-2];

odd = [odd;odd+3*V;odd+2*3*V;odd+3*3*V];
even = [even;even+3*V;even+2*3*V;even+3*3*V];

odd = sort(odd);
even = sort(even);

S = A(even,even) - A(even,odd)*(A(odd,odd)\A(odd,even));
y = zeros(length(odd));

y = A(odd,odd)\b(odd);
[x(even),iter,relres,resvec] = bicgstab(S,b(even)-A(even,odd)*y,tol,100);
%x(even) = S\(b(even)-A(even,odd)*y);
x(odd) = y - A(odd,odd)\(A(odd,even)*x(even));