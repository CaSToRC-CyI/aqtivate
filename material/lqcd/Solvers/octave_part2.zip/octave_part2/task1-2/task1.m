% Part I of Task I 
% Testing CG on Poisson equation
% Measuring convergence in different norms
fprintf(stdout,'*** Task I: Conjugate Gradients ***\n\n');

%%%
fprintf (stdout,'\nPush a button to continue with part I\n');
fprintf (stdout,'Diagonal Preconditioning\n');
pause
clear all
%%%

N = 32;
fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
A = laplace(N);
m = size(A,1);
e = zeros(m,1);
e(N*(N+1)/2) = 1;
b = e;
beta = norm(b);
b = b/beta;
xstar = A\b;

[x, flag, relres, iter, resvec, eigest, T, xvec] = pcg_local(A,b,10^(-10),500);

enormAvec = zeros(iter+1,1);
enormvec = zeros(iter+1,1);

for i = 1:iter+1
  e = xstar-xvec(:,i);
  enormAvec(i) = sqrt(e'*A*e);
  enormvec(i) = sqrt(e'*e);
end

fprintf(stdout,'CG converged in %3d iterations to  ||r||_2 = %e\n',iter,relres);
fprintf(stdout,'                                   ||e||_2 = %e\n',enormvec(end));
fprintf(stdout,'                                   ||e||_A = %e\n',enormAvec(end));

[x, flag, relres, iterD, resvecD, eigest, T, xvecD] = pcg_local(A,b,10^(-10),500,"jacobi",[],[],A);

enormAvecD = zeros(iterD+1,1);
enormvecD = zeros(iterD+1,1);

for i = 1:iter+1
  e = xstar-xvecD(:,i);
  enormAvecD(i) = sqrt(e'*A*e);
  enormvecD(i) = sqrt(e'*e);
end

fprintf(stdout,'PCG converged in %3d iterations to ||r||_2 = %e\n',iter,relres);
fprintf(stdout,'                                   ||e||_2 = %e\n',enormvec(end));
fprintf(stdout,'                                   ||e||_A = %e\n',enormAvec(end));


figure(1)
semilogy(0:iter,resvec(1:iter+1),'x','MarkerSize',2,...
         0:iter,enormvec(1:iter+1),'x','MarkerSize',2,...
         0:iter,enormAvec(1:iter+1),'x','MarkerSize',2,...
         0:iterD,resvecD(1:iterD+1),'-','MarkerSize',2,...
         0:iterD,enormvecD(1:iterD+1),'-','MarkerSize',2,...
         0:iterD,enormAvecD(1:iterD+1),'-','MarkerSize',2);
box off;
grid on;
xlabel('iterations');
title(cat(2,'Poisson on a ',num2str(N),'x',num2str(N),' grid'));
legend('CG ||r||_{2}','CG ||e||_{2}','CG ||e||_{A}','PCG ||r||_{2}','PCG ||e||_{2}','PCG ||e||_{A}')

%%% Task I Part II
% SSOR Preconditioning

%%%
fprintf (stdout,'\nPush a button to continue with part II\n');
fprintf (stdout,'SSOR Preconditioning\n');
pause
%%%

% Part II of Task I
% SSOR Preconditioning

[x, flag, relres, iterSSOR, resvecSSOR, eigest, TSSOR, xvecSSOR] = pcg_local(A,b,10^(-10),500,"ssor",[],[],A,1.5);

enormAvecP = zeros(iter+1,1);
enormvecP = zeros(iter+1,1);

for i = 1:iter+1
  e = xstar-xvecSSOR(:,i);
  enormAvecSSOR(i) = sqrt(e'*A*e);
  enormvecSSOR(i) = sqrt(e'*e);
end

fprintf(stdout,'PCG converged in %3d iterations to ||r||_2 = %e\n',iter,relres);
fprintf(stdout,'                                   ||e||_2 = %e\n',enormvec(end));
fprintf(stdout,'                                   ||e||_A = %e\n',enormAvec(end));


figure(2)
semilogy(0:iter,resvec(1:iter+1),'x','MarkerSize',2,...
         0:iter,enormvec(1:iter+1),'x','MarkerSize',2,...
         0:iter,enormAvec(1:iter+1),'x','MarkerSize',2,...
         0:iterSSOR,resvecSSOR(1:iterSSOR+1),'-','MarkerSize',2,...
         0:iterSSOR,enormvecSSOR(1:iterSSOR+1),'-','MarkerSize',2,...
         0:iterSSOR,enormAvecSSOR(1:iterSSOR+1),'-','MarkerSize',2);
box off;
grid on;
xlabel('iterations');
title(cat(2,'Poisson on a ',num2str(N),'x',num2str(N),' grid'));
legend('CG ||r||_{2}','CG ||e||_{2}','CG ||e||_{A}','PCG ||r||_{2}','PCG ||e||_{2}','PCG ||e||_{A}')

%%%
fprintf (stdout,'\nPush a button to continue with part III\n');
fprintf (stdout,'The Preconditioned Spectrum and the CG polynomial\n');
pause
%%%

% Part III of Task I
% Preconditioned Spectrum
% Conjugate Gradients Polynomial

N = 8;
fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
A = laplace(N);
m = size(A,1);
e = zeros(m,1);
e(N*(N+1)/2) = 1;
b = e;
beta = norm(b);
b = b/beta;
xstar = A\b;

ww = eig(A);

B = zeros(m);
opts = cell(2,1);
opts{1} = A;
opts{2} = 1.5;
for i = 1:m
  B(:,i) = ssor(A(:,i),A,1.5);
end
wwP = eig(B);

[x, flag, relres, iterSSOR2, resvecSSOR2, eigest, TSSOR, xvecSSOR2] = pcg_local(A,b,10^(-10),500,"ssor",[],[],A,1.5);

fprintf (stdout,'\nPush a button to continue with part III\n');
pause();

figure(3)
t = (0:.01:8)';
for i = 1:10
  l = eig(TSSOR(1:i,1:i));
  p = 1;
  for j = i:-1:1
    p = p.*(t-l(j))/(-l(j));
  end
  plot(real(wwP),imag(wwP),'bx','Markersize',2,real(l),imag(l),'r*', 'Markersize',2,t,p,'r');
  title(cat(2,'the PCG polynomial p_{',num2str(i),'}'))
  legend('eigenvalues of SA','roots of p_{k}','p_{k}')
  grid on
  box off
  axis([0 2 -1 1]);
  pause(1)
end


#{
%%% Task I Part IV
% ILU Preconditioning

%%%
fprintf (stdout,'\nPush a button to continue with part IV\n');
fprintf (stdout,'ILU Preconditioning\n');
pause
%%%

N = 32;
fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
A = laplace(N);
m = size(A,1);
e = zeros(m,1);
e(N*(N+1)/2) = 1;
b = e;
beta = norm(b);
b = b/beta;
xstar = A\b;

resvecILU = cell(5,1);
iterILU = zeros(5,1);

it = 1;
for tt = -3:-1:-7
  [L,U,P,Q] = luinc(A,10^(-1));
  P = sparse(1:m,P,ones(m,1),m,m);
  Q = sparse(1:m,Q,ones(m,1),m,m);
  L = P'*L;
  U = U*Q';
  
  [x, flag, relres, iterILU(it), resvecILU{it}] = pcg_local(A,b,10^(-10),500,U,L,[]);
  
  fprintf(stdout,'ILU CG (tol=%e) converged in %3d iterations to ||r||_2 = %e\n',10^(tt),iterILU(it),relres);
  it = it+1;
end

figure(4)
semilogy(0:iter,resvec(1:iter+1),'.','MarkerSize',2,...
         0:iterILU(1),resvecILU{1}(1:iterILU(1)+1),'-','MarkerSize',2,...
         0:iterILU(2),resvecILU{2}(1:iterILU(2)+1),'-','MarkerSize',2,...
         0:iterILU(3),resvecILU{3}(1:iterILU(3)+1),'-','MarkerSize',2,...
         0:iterILU(4),resvecILU{4}(1:iterILU(4)+1),'-','MarkerSize',2,...
         0:iterILU(5),resvecILU{5}(1:iterILU(5)+1),'-','MarkerSize',2);
box off;
grid on;
xlabel('iterations');
ylabel('||r||_{2}');
title(cat(2,'Odd-Even-CG'));
legend('CG','ILU-CG 10^{-3}','ILU-CG 10^{-4}','ILU-CG 10^{-5}','ILU-CG 10^{-6}','ILU-CG 10^{-7}',"location",'east outside')

figure(11)
spy(A,2);
title('non-zeroes in A');
xlabel(cat(2,'nnz=',num2str(nnz(A))))
figure(12)
spy(L+U,2);
title('non-zeroes in L and U (droptol=10^{-7})');
xlabel(cat(2,'nnz=',num2str(nnz(L+U))));
#}

%%% Task I Part IV
% odd-even preconditioning

%%%
fprintf (stdout,'\nPush a button to continue... to part IV\n');
fprintf (stdout,'odd-even preconditioning\n\n');
pause
%%%

N = 32;
fprintf(1,'Running Poisson-Test on %dx%d grid\n',N,N);
A = laplace(N);
m = size(A,1);
e = zeros(m,1);
e(N*(N+1)/2) = 1;
b = e;
beta = norm(b);
b = b/beta;
xstar = A\b;

resvecOE = cell(5,1);
iterOE = zeros(5,1);

it = 1;
for tt = -1:-2:-9
  [x, flag, relres, iterOE(it), resvecOE{it}] = pcg_local(A,b,10^(-10),500,"oddeven2d",[],[],A,10^(tt));
  
  fprintf(stdout,'odd-even CG (tol=%e) converged in %3d iterations to ||r||_2 = %e\n',10^(tt),iterOE(it),relres);
  it = it+1;
end

figure(5)
semilogy(0:iter,resvec(1:iter+1),'x','MarkerSize',2,...
         0:iterOE(1),resvecOE{1}(1:iterOE(1)+1),'-','MarkerSize',2,...
         0:iterOE(2),resvecOE{2}(1:iterOE(2)+1),'-','MarkerSize',2,...
         0:iterOE(3),resvecOE{3}(1:iterOE(3)+1),'-','MarkerSize',2,...
         0:iterOE(4),resvecOE{4}(1:iterOE(4)+1),'-','MarkerSize',2,...
         0:iterOE(5),resvecOE{5}(1:iterOE(5)+1),'-','MarkerSize',2);
box off;
grid on;
xlabel('iterations');
ylabel('||r||_{2}');
title(cat(2,'Odd-Even-CG'));
legend('CG','OE-CG 10^{-1}','OE-CG 10^{-3}','OE-CG 10^{-5}','OE-CG 10^{-7}','OE-CG 10^{-9}',"location",'eastoutside');

%%%
fprintf (stdout,'\nPush a button to continue... to part VI\n');
fprintf (stdout,'comparison of preconditioners\n\n');
pause
%%%

% Part IV of Task I
% comparison of preconditioners

figure(6)
semilogy(0:iter,resvec(1:iter+1),'x','MarkerSize',2,...
         0:iterSSOR,resvecSSOR(1:iterSSOR+1),'-','MarkerSize',2,...
         %0:iterILU(1),resvecILU{1}(1:iterILU(1)+1),'-','MarkerSize',2,...
         0:iterOE(1),resvecOE{1}(1:iterOE(1)+1),'-','MarkerSize',2);
box off;
grid on;
xlabel('iterations');
ylabel('||r||_{2}');
title(cat(2,'comparison of pCG-variants'));
%legend('CG','SSOR-CG','ILU 10^{-3}','OE-CG 10^{-1}',"location",'eastoutside')
legend('CG','SSOR-CG','OE-CG 10^{-1}',"location",'eastoutside')

%%%
fprintf (stdout,'\nPush a button to finish Task I\n\n');
pause
clear all
close all
%%%
