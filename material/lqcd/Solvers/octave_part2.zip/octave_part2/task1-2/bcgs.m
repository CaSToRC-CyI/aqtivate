function x = bcgs(b,varargin) %A,x0,block,color)

A = varargin{1};
gridgeom = varargin{2};
blockgeom = varargin{3};

[block,color] = blockand2color4DQCD(gridgeom,blockgeom);

m = size(A,1);

x = zeros(m,1);

% determine the number of colors
cc = unique(color);
nc = length(cc);

% indexsets
for i = 1:nc
   ind(i,:) = find(color == cc(i));
end

r = b - A*x;
for i = 1:nc
   for j = 1:length(ind(i,:))
      bi = block(ind(i,j),:);
      x(bi) = x(bi) + A(bi,bi)\r(bi);
   end
   r = b - A*x;
end

%r = b - A*x;

%for i = 1:length(blocks)
%   bi = blocks{i};
%   x(bi) = x(bi) + A(bi,bi)\r(bi);
%   r = b - A*x;
%end