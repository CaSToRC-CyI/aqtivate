function [m,em]=meff(bp)
# simple, effective mass, based on exp
   NT=size(bp)(1);
   NB=size(bp)(2)-1;
   mb=log(bp([end 1:end-1],:)./bp);
   m=real(mb(:,NB+1));
   em=berr(real(mb));
endfunction