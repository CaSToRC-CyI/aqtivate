function res=boot(p,NB)
# produce bootstrapped propagator form
# individual propagator
   nconf=length(p)
   NT=length(p{1})
# bootstrap asignment index
   idx=unidrnd(nconf,nconf,NB);
   res=zeros(NT,NB+1);
   for b=1:NB
       for c=1:nconf
           res(:,b)+=p{idx(c,b)}';
       end
   end
   for c=1:nconf
       res(:,NB+1)+=p{c}';
   end
   res/=nconf;
endfunction