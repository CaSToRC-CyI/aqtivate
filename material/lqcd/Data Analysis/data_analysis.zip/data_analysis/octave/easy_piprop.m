function newprp=easy_piprop(NT,mq,n)
# pseudo-propagator generation
# please don't look at this function initially!
   if (nargin<3)
       n=1;
   end
# masses, couplings and noise of the contributions
   ainv=1.5; # inverse lattice spacing in GeV
   Z=1; # renormalization factor
   l3=2.3;
   l4=4.4;
   mpp=0.135/ainv;
   F=0.086/ainv;
   sig=(0.245/ainv)^3;
   m0=-0.1;
   M=sqrt(2*(mq-m0)*sig/F^2);
   x=M/(4*pi*F);
   mpi=real(M*sqrt(1-x*(l3/2+log(mpp/M))));
   1+x*(l4+2*log(mpp/M));
   fpi=real(F*sqrt(1+x*(l4+2*log(mpp/M)))/Z);
   noisepi=0.004/M;
   mas=[3,1,0.6,mpi];
   cop=[0.0002/ainv^4,0.0007/ainv^4,0.0005/ainv^4,mpi*fpi^2/2];
   sig=[0.1,0.04,0.04,noisepi];
   sym=1;
   gapmas=0.2;
   nm=length(mas);
   for i=1:n
       newprp{i}=zeros(1,NT);
       for j=1:nm
           newprp{i}+=exxp(cop(j),mas(j),NT,sym,sig(j)).*lognnoise(NT,gapmas,sig(j));
       end
   end
endfunction
