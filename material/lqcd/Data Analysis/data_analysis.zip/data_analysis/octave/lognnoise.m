function res=lognnoise(NT,m,sig)
# load package containing normrnd
   pkg load statistics    
# lognormal noise with correlation
   NT2=NT/2;
# first define maximum noise of fourier components
# only components 1:NT/2 need to be defined
   siz=min(exp(-(m*NT)./((2*(pi-m)).*(1:NT2))),exp(-(m*NT)./((2*(pi-m)).*(NT-1:-1:NT2))));
# absolute part of fourier noise coefficients   
   r=normrnd(0,siz);
# phase of 1:NT2-1
   phi=rand(1,NT2-1)*2*pi;
# assemble complex fourier coefficients
   cp=zeros(1,NT);
   cp(2:NT2)=r(NT2-1)*exp(i*phi);
   cp(NT2+1)=r(NT2);
   cp(NT2+2:NT)=conj(cp(NT2:-1:2));
   cp(1)=0;
# normalize
   res=exp(real(ifft(cp)([2:end 1])));
   sig=10*sig;
   res=res.*(lognrnd(-sig^2/2,sig)/sum(res)*NT);
endfunction
