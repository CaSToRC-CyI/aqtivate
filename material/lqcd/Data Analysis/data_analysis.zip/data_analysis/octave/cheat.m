function [mpi,fpi,dif]=cheat(mq)
# cheat: computing true m and f
# ainv=2
# physical mq:-0.09732066477
# physical fpi:0.053934
# ainv=1.5
# physical mq:-0.096427553
# physical fpi:0.071912
# for easy_piprop
   ainv=1.5; # inverse lattice spacing in GeV
   Z=1; # renormalization factor
   l3=2.3;
   l4=4.4;
   mpp=0.135/ainv;
   F=0.086/ainv;
   sig=(0.245/ainv)^3;
   m0=-0.1;
   M=sqrt(2*(mq-m0)*sig/F^2);
   x=M/(4*pi*F);
   mpi=real(M*sqrt(1-x*(l3/2+log(mpp/M))));
   1+x*(l4+2*log(mpp/M));
   fpi=real(F*sqrt(1+x*(l4+2*log(mpp/M)))/Z);
   dif=mpi-mpp;
endfunction