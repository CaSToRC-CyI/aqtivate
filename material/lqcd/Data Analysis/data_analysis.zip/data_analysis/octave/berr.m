function res=berr(ba)
warning ("off", "Octave:broadcast");
# compute bootstrap error from
# bootstrap file ba
   NT=size(ba)(1);
   NB=size(ba)(2)-1;
# bootstrap asignment index
    x0=ba(:,NB+1);
    xd=sum(ba(:,1:NB),2)/NB;
    s=sum((ba(:,1:NB)-repmat(xd,1,NB)).^2,2);
    res=sqrt(s/(NB-1));
endfunction