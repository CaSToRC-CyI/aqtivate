function [fpi,efpi,q,qc]=chiralfit_solution(fb,mb,nmodes,noboot,pl)
# fit fb vs. mb
# where both are bootstrapped
# if noboot==1, only central values are computed
    
# fix lattice spacing
   ainv=1.5;
   mpi2=(0.135/ainv)^2;

   N=length(fb);
   NB=length(fb{1})-1;
   if (N!=length(mb))
       disp("fb and mb have different length!")
   end
# check wheter to compute central value only
   beg=1;
   if (nargin>=4)
       if (noboot==1)
           beg=NB+1;
           disp("Only central value computed!")
       end
   end

   global _f;
   global _m;
   global _er={};
   global _n;
   _er={};

   for i=1:N;
# use mpi^2 as x-axis
       mb{i}=mb{i}.^2;
       _er{i}=icor([mb{i}',fb{i}']',nmodes);
   end
   _n=N;

   warning ("off", "Octave:SQP-QP-subproblem");
   fpi=zeros(1,NB+1);
# loop over all bootstrap samples
   for b=beg:NB+1
       for i=1:N
           _m(i)=mb{i}(b);
           _f(i)=fb{i}(b);
       end
# initial guesses
       k0=(_f(N)-_f(1))/(_m(N)-_m(1));
       d0=_f(1)-k0*_m(1);
       stp=[d0,k0];
# do the constrained fit
       [par,ch2c,info]=sqp(stp',@constrainedfit,[],[],[],[],1000);
       if ((info!=101)&&(info!=104))
           disp("Constraint solver did not converge")
           info
           b
       end
# do the full fit
       stp=par';
       for i=1:N
           stp=[stp _m(i)];
       end
       [par,ch2,info]=sqp(stp',@fullfit,[],[],[],[],1000);
       if ((info!=101)&&(info!=104))
           disp("Full solver did not converge")
           info
           b
       end
       db(b)=par(1);
       kb(b)=par(2);
   end
   npar=length(par); # number of fit parameters
   ndof=2*N-npar;
   for i=1:NB+1
       fpib(i)=fps(mpi2,[db(i),kb(i)]);
   end
   fpi=fpib(end);
   efpi=berr(fpib);
   q=fitq(ch2,ndof);
   qc=fitq(ch2c,ndof);
# optional plotting
   if (nargin>=5)
       if (pl==1)
           maxm=max(_m)*1.1;
           dm=maxm/50;
           mf=0:dm:maxm;           
           ff=fps(mf,[db(end),kb(end)]);
           phx=[mpi2,mpi2];
           phy=[min(ff)*0.9,max(ff)*1.1];
           ex=[mpi2,mpi2];
           ey=[fpi-efpi,fpi+efpi];
           xx=[mpi2];
           xy=[fpi];
           h=plot(phx,phy,"m-",mf,ff,"g-",_m,_f,"b.",ex,ey,"r-",xx,xy,"ro");
           hold on;
# produce error ellipses
           phi=0:pi/50:2*pi;
           for p=1:N
               ephi=[cos(phi)'/sqrt(_er{p}(1,1)),sin(phi)'/sqrt(_er{p}(2,2))];
               for i=1:length(phi)
                   ephi(i,:)/=sqrt(ephi(i,:)*ephi(i,:)');
                   ephi(i,:)/=sqrt(ephi(i,:)*_er{p}*ephi(i,:)');
               end
               x=ephi(:,1)+_m(p);
               y=ephi(:,2)+_f(p);
               plot(x,y,"b-");
           end
           hold off;
           set(h(4),"linewidth", 2);
# largest y-error
           adf=0;
           for i=1:N
               if (1/sqrt(_er{i}(2,2))>adf)
                   adf=1/sqrt(_er{i}(2,2));
               end
           end
# rescale y-axis
           axis([0,max(mf),min([ff _f])-2*adf,max([ff _f])+2*adf]);
       end
   end
endfunction

function chisq=constrainedfit(par)
# chi^2 function for constrained fpi-mpi^2 fit
   global _f _m _er _n

   chisq=0;
   for i=1:_n
       mm=_m(i);
       ff=fps(mm,par);
       ex=[_m(i)-mm,_f(i)-ff];
       chisq+=ex*_er{i}*ex';
   end
   chisq;
endfunction

function chisq=fullfit(par)
# chi^2 function for full fpi-mpi^2 fit
   global _f _m _er _n

   npar=2;
   chisq=0;
   for i=1:_n
       mm=par(npar+i);
       ff=fps(mm,par(1:npar));
       ex=[_m(i)-mm,_f(i)-ff];
       chisq+=ex*_er{i}*ex';
   end
   chisq;
endfunction

function ff=fps(m,c)
# the actual fit function
    ff=c(1)+c(2)*m;
endfunction