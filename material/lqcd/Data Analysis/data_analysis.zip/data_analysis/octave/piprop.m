function newprp=piprop(NT,n)
# pseudo-propagator generation
# please don't look at this function initially!
   if (nargin==1)
       n=1;
   end
# masses, couplings and noise of the contributions
   mas=[3,1,0.4,0.203184];
   cop=[5,3,2,1];
   sig=[0.3,0.1,0.1,0.1];
   sym=1;
   gapmas=0.2;
   nm=length(mas);
   for i=1:n
       newprp{i}=zeros(1,NT);
       for j=1:nm
           newprp{i}+=exxp(cop(j),mas(j),NT,sym,sig(j)).*lognnoise(NT,gapmas,sig(j));
       end
   end
endfunction
