function plotsymplat(pb)
# plot mass plateau
   NT=size(pb)(1);
   t=1:NT-1;
   [m,e]=meffcosh(pb);
   errorbar(t,m,e);
   axis([0,NT]);
endfunction
