NT=64
NBOOT=100
NCONF=100

t=1:NT;
prp=rndprop(NT,NCONF);
bp=boot(prp,NBOOT);

plotprop(bp);
plotplat(bp);