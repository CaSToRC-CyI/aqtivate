NT=64
NBOOT=100
NCONF=100

masstab=[-0.0964,-0.0965]

beg=length(fb);

for i=beg+1:beg+length(masstab)
    prp=easy_piprop(NT,masstab(i-beg),NCONF);
    bp{i}=boot(prp,NBOOT);
    [m,em,c,ec,q,mb{i},cb{i}]=massfit(bp{i},-1,15,30);
    fb{i}=sqrt(abs(cb{i}))./mb{i};
end
[fpi,efpi,q,qc]=chiralfit(fb,mb,-1,1)