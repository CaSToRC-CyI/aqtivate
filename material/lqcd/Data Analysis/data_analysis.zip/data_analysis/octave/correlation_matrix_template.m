function ev=correlation_matrix_template(bp)
# this is a template for a routine that should
# compute the normalized correation matrix and
# its eigenvalues from a bootstrap array
   N=size(bp)(1);    # number of points to correlate
   NB=size(bp)(2)-1; # number of bootstrap samples
                     # keep in mind that NB+1 indexes
                     # the ensemble average
   
# compute the normalized correlation matrix cor here
# remember that the diagonal elements are 1
# and the matrix is symmetric

   ev=eig(cor);
endfunction