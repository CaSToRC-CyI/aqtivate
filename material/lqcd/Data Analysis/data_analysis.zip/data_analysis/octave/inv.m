function res=inv(m,nm)
# invert correlation matrix m keeping only 
# nm modes
   N=size(m)(1);
   [v,e]=eig(m);
# cut out bad modes
   e(1:N-nm,1:N-nm)=0;
   trunc=v*e*v';
# set diagonal to 1
   for i=1:N
       trunc(i,i)=1;
   end
   res=trunc^(-1);
endfunction