function res=fitq(chi2,ndof)
# fit quality from chi^2 and 
# number of degrees of freedom
   res=1-gammainc(chi2/2,ndof/2);
endfunction