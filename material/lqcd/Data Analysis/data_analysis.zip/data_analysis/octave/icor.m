function ic=icor(bp,nmode)
# compute inverse correlation matrix from bootstrap samples
   N=size(bp)(1);
   NB=size(bp)(2)-1;
   
# correct too large nmode
   nmode=min(nmode,N);
# -1 means all modes taken
   if (nmode<0)
       nmode=N;
   end
   
# take out normalization
   bav=sum(bp(:,1:NB),2)/NB;
   ac=sqrt((sum(bp(:,1:NB).^2,2)/NB-bav.^2)*(1+(1/(NB-1))));

# form the covariance matrix    
   cor=zeros(N);
   if (nmode==0)
       ic=diag(1./ac.^2);
   else
       for x=1:N
           for y=1:N
               cor(y,x)=(bp(y,1:NB)-bav(y))*(bp(x,1:NB)-bav(x))'/(NB-1)/(ac(x)*ac(y));
           end
       end
# call inversion
       zw=inv(cor,nmode);
# multiply back normalization
       ic=zw./(ac*ac');
   end
endfunction