function ev=correlation_matrix_solution(bp)
# this is a template for a routine that should
# compute the normalized correation matrix and
# its eigenvalues from a bootstrap array
   N=size(bp)(1);    # number of points to correlate
   NB=size(bp)(2)-1; # number of bootstrap samples
                     # keep in mind that NB+1 indexes
                     # the ensemble average
   
# take out normalization
   bav=sum(bp(:,1:NB),2)/NB;
   ac=sqrt((sum(bp(:,1:NB).^2,2)/NB-bav.^2)*(1+(1/(NB-1))));

# form the covariance matrix    
   cor=zeros(N); # initialize cor as N*N matrix
   for x=1:N
       for y=1:N
           cor(y,x)=(bp(y,1:NB)-bav(y))*(bp(x,1:NB)-bav(x))'/(NB-1)/(ac(x)*ac(y));
       end
   end
   ev=eig(cor);
endfunction