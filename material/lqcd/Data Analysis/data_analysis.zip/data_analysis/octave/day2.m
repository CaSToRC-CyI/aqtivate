# this is an example file for generating a set of ensembles
# that we will use to extrapolate-interpolate an observacle
# to the "physical point"

# our inverse "lattice spacing" is 1/a=1.5GeV
# so the "physical" target a*m_pi=0.09
clear all

NT=64
NBOOT=100
NCONF=100

# a "bare quark mass"
mq=-0.01

# produce an ensemble at bare quark mass mq
prp=easy_piprop(NT,mq,NCONF);
bpr=boot(prp,NBOOT);
m=massfit(bpr,0,15,30,1,1)

# check where m is compared to the target 0.09
# and adjust mq.



# the following section does a f_pi vs. m_pi^2 fit
# it requires a working chiralfit routine first
# it is a good idea to find a reasonable table of
# quark masses before proceeding

# a random table of quark masses
masstab=[0,-0.04,-0.06,-0.08]

for i=1:length(masstab)
    prp=easy_piprop(NT,masstab(i),NCONF);
    bp{i}=boot(prp,NBOOT);
# mb and cb are bootstrap results for m and c
    [m,em,c,ec,q,mb{i},cb{i}]=massfit(bp{i},0,15,30);
# extract f from c=f^2*m^2
    fb{i}=sqrt(abs(2*cb{i}./mb{i}));
end

# now it is time to complete the fit function
# [fpi,efpi,q,qc]=chiralfit_template(fb,mb,-1,0,1)
# if the implementation is correct, it should give
# the same result as
[fpi,efpi,q,qc]=chiralfit_solution(fb,mb,-1,0,1)
