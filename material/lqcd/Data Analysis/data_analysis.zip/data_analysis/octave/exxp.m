function res=exxp(c,m,NT,sym,ti,tf)
# simple exponential function with
# optional backward contributions
   if (nargin<=5)
       ti=1;
       tf=NT;
   end
   res=ti:tf;
   res=c*(exp(-res*m)+sym*exp(-(NT-res)*m));
# sum winding contributions
   res=res*(1/(1-exp(-m*NT)));
endfunction