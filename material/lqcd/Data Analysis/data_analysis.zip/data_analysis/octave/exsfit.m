function [m,em,c,ec,q,m2,em2,c2,ec2,mb,cb]=exsfit(bp,nmodes,ti,tf,noboot,plt)
# cosh mass fit
# nmodes is the number of eigenmodes used
# to construct the inverse correlation matrix
# full bootstrap array bp is given, only
# timeslices ti to tf are used for the fit
    
   NT=size(bp)(1);
   NB=size(bp)(2)-1;
# check wheter to compute central value only
   beg=1;
   if (nargin>=5)
       if (noboot==1)
           beg=NB+1;
           disp("Only central value computed!")
       end
   end
   global _pr;
   global _er;
   global _nt;
   global _ti;
   global _tf;
   
   _er=icor(bp(ti:tf,:),nmodes);
   _nt=NT;
   _ti=ti;
   _tf=tf;
   
   mb=zeros(1,NB+1);
   cb=zeros(1,NB+1);
   m2b=zeros(1,NB+1);
   c2b=zeros(1,NB+1);
   warning ("off", "Octave:SQP-QP-subproblem");
# loop over all bootstrap samples
   for b=beg:NB+1
       _pr=bp(ti:tf,b);
# initial guesses
       t2=floor((tf-ti)/2); # need a symmetric interval
       tm=1+t2;
       te=1+2*t2;
       m0=real(acosh((_pr(1)+_pr(te))/(2*_pr(tm)))/t2);
       c0=_pr(1)/(exp(-m0*ti)+exp(-m0*(NT-ti)));
       stp=[m0,c0,1,0];
# do the actual fit
       [par,ch2,info,iter]=sqp(stp',@cshfit,[],[],[],[],1000);
       if ((info!=101)&&(info!=104))
           disp("Solver did not converge")
           info
       end
       mb(b)=abs(par(1));
       cb(b)=par(2);
       m2b(b)=mb(b)*exp(par(3)^2);
       c2b(b)=par(4);
   end
   npar=length(par); # number of fit parameters
   ndof=tf-ti+1-npar;
   m=mb(end);
   c=cb(end);
   em=berr(mb);
   ec=berr(cb);
   q=fitq(ch2,ndof);
   m2=m2b(end);
   c2=c2b(end);
   em2=berr(m2b);
   ec2=berr(c2b);
# finally plot the result if wanted
   if (nargin>=6)
       if (plt==1)
           plot(0:NT,epr(par,NT,0,NT),"g");
           axis([0,NT]);
           hold on
           h=plot(ti:tf,epr(par,NT,ti,tf),"r");
           set(h(1),"linewidth", 2);
           plotprop(bp);
           hold off
       end
   end
endfunction

function chisq=cshfit(par)
# chi^2 function for cosh-fit
   global _pr;
   global _er;
   global _nt;
   global _ti;
   global _tf;

   ex=_pr'-epr(par,_nt,_ti,_tf);
   chisq=ex*_er*ex';
endfunction

function res=epr(par,nt,ti,tf)
    res=exxp(par(2),abs(par(1)),nt,1,ti,tf)+exxp(par(4),abs(par(1))*exp(par(3)^2),nt,1,ti,tf);
endfunction
