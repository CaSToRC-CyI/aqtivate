# this is the file that demonstrates how to get started with the analysis

# first let us produce one fake "pion" propagator
myprop1=piprop(16)

# this is a cell array of row vectors. It only
# contains one cell at the moment. This is our first
# fake propagator. The row vector has size 16, this is
# our time extent.

# let's look at the propagator:
plot(myprop1{1})

# as you can see it decays. The origin is at 16. if you
# rather like the origin at 1, just shift the array
plot(myprop1{1}([end 1:end-1]))

# it's nicer to look at it with a logscale in y
semilogy(myprop1{1})

# now let's produce 100 propagators with NT=64
prop=piprop(64,100);

# let's look at one of them
semilogy(prop{1})

# now we produce 200 bootstrap samples from
# the 100 propagators
bp=boot(prop,200);

# bp has 201 columns, each containig a 64-row 
# bootstrapped propagator. The last column(201)
# contains the full ensemble average. Let us plot it.
semilogy(bp(:,end))

# there is a procedure for plotting it with bootstrap
# errors
plotprop(bp)

# let's see where to extract the mass from
plotplat(bp)

# or with the symmetrized (cosh) effective mass
plotsymplat(bp)

# let's try to fit it in the interval 10-25
# we will also set a few preferences:
uncorrelated_fit=0
fully_correlated_fit=-1 

central_value_only=1
full_bootstrap_fit=0

do_plot=1
dont_plot=0

massfit(bp,uncorrelated_fit,10,25,central_value_only,do_plot)

# we want to see more than just the mass
[m,em,c,ec,fitq]=massfit(bp,uncorrelated_fit,10,25,central_value_only,do_plot)

# of course this fit quality is meaningless, let's try a correlated fit
[m,em,c,ec,fitq]=massfit(bp,fully_correlated_fit,10,25,central_value_only,do_plot)

# does it work? how about taking a few ev's, say 3?
[m,em,c,ec,fitq]=massfit(bp,3,10,25,central_value_only,do_plot)

# it is time to compute the correlation matrix now
# please complete the "correlation_matrix_template"
# so that it gives the same result as
correlation_matrix_solution(bp(10:25,:))

# now have fun playing with eigenmodes, fitranges,
# number of configurations, number of bootstrap samples
# and the time extent.

# when you are done (i.e. when you believe you have the correct
# mass with a reliable error), please let me know 2 numbers: the pion mass
# that you obtained and the error, so i can plot results
    
# if you are done with the pion, you can try to extract
# the ground state mass of a fake "rho" correlator. you
# can get e.g.100 propagators with
rprop=rhoprop(64,100);

# and proceed as with the pion

# have fun!
