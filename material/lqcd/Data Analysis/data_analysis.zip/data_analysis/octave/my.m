NT=64
NBOOT=100
NCONF=100

masstab=[-0.097,-0.0965,-0.096,-0.095,-0.094]

for i=1:length(masstab)
    prp=easy_piprop(NT,masstab(i),NCONF);
# symmetrize the propagators
    for c=1:length(prp)
        prp{c}=(prp{c}+prp{c}([end-1:-1:1 end]))/2;
    end
    bp{i}=boot(prp,NBOOT);
    [m,em,c,ec,q,mb{i},cb{i}]=massfit(bp{i},0,15,30,0,1);
# one could try an excited state fit, too
#   [m,em,c,ec,q,m2,em2,c2,ec2,mb{i},cb{i}]=exsfit(bp{i},0,10,30,0,1);
    fb{i}=sqrt(abs(2*cb{i}./mb{i}));
end

[fpi,efpi,q,qc]=chiralfit_solution(fb,mb,-1,0,1)
[fpi,efpi,q,qc]=chiralfit_quadratic(fb,mb,-1,0,1)
