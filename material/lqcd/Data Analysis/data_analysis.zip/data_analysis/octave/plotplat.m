function plotplat(pb)
# plot mass plateau
   NT=size(pb)(1);
   t=0.5:NT-0.5;
   [m,e]=meff(pb);
   errorbar(t,m,e);
   axis([0,NT]);
endfunction
