function newprp=rhoprop(NT,n)
# pseudo-propagator generation
# please don't look at this function initially!
   if (nargin==1)
       n=1;
   end
# masses, couplings and noise of the contributions
   mas=[3,0.8,0.6,0.45];
   cop=[5,1,1,0.1];
   sig=[0.3,0.1,0.1,0.1];
   sigo=0.01;
   siga=0.005;
   sym=1;
   gapmas=0.2;
   nm=length(mas);
   for i=1:n
       newprp{i}=zeros(1,NT);
       for j=1:nm
           newprp{i}+=exxp(cop(j),mas(j),NT,sym,sig(j)).*lognnoise(NT,gapmas,sig(j));
       end
# multiplicative noise
       for t=1:NT
           c=newprp{i}(t);
           newprp{i}(t)+=normrnd(0,5*sigo*c/sqrt(sigo^2+c^2));
       end
# additive noise
   newprp{i}+=normrnd(0,siga,1,NT);
   end
endfunction
