function plotprop(pb)
# plot propagator
   NT=size(pb)(1);
   t=1:NT;
   p=pb(:,end);
   pe=berr(pb);
   semilogyerr(t,p,pe);
   axis([0,NT]);
endfunction
