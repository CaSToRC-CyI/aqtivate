function [m,em]=meffcosh(bp)
# analytic effective mass
# FOR SYMMETRIC PROPAGATORS
   NT=size(bp)(1);
   NB=size(bp)(2)-1;
   mb=acosh((bp([end 1:end-1],:)+bp([2:end 1],:))./(2*bp));
   m=real(mb(1:NT-1,NB+1));
   em=berr(real(mb(1:NT-1,:)));
endfunction