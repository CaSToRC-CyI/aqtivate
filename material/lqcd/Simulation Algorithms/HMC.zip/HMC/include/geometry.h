#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "schwinger.h"

/* hopping.c */
extern void hopping(int h[V][2*D]);

#endif
